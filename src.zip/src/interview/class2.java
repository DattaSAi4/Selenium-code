package interview;

public class class2 extends class1 {
	
	public static void main(String[] args) {
		             
		           class0 s1 = new class2();
		           s1.addition();
	}

}
