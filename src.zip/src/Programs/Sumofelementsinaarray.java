package Programs;

public class Sumofelementsinaarray {
	
	public static void main(String[] args) {
		
		int[] a = {1,2,34,5,7};
		
		int sum =0;
		for( int s1:a)
		{
			 sum = sum+s1;
		}
		System.out.println("The Sum of the elements in the array :" +sum);
		
	
	}

}
