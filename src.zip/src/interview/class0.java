package interview;

public interface class0 {
	
	
	public void addition();
	
	public void substraction();
	
	public void multiplication();

}
