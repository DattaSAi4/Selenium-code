package Com.Javatopics;

/*package 
 * 
 * It is a container which  helps us the seggrate the source files 
 * */
public class package1 {

}
