package constructor;

public class c1 {
	
	int a =10;
	int b =20;
	
	{
		System.out.println("Datta Sai Vinay");
	}
	
	
	c1(int a)
	{
		System.out.println(a);
	}
	c1 (int a , int b)
	{
		int c=a+b;
		System.out.println("The Addition of given  two number ");
	}

}
