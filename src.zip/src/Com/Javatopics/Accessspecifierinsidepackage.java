package Com.Javatopics;

public class Accessspecifierinsidepackage {
	
	public static void main(String[] args) {
		
		Accessspecifiersinsideclass    s3=  new 	Accessspecifiersinsideclass();
		s3.addition();
		s3.substration();
		s3.multiplication();
		//s3.divison private method we cant access out side the class
	}
	


}
