package Programs;

public class Whileanddowhile {
	
	public static void main(String[] args) {
		
		int a=10;
		int b =0;
		
		while(a!=0)
		{
			System.out.println(a--);
		}
		
		do
		{
		   System.out.println("The character of b"+b);	
		}
		while(b!=0);
	}
	
	

}
