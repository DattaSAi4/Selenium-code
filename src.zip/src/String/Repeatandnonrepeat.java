//WAP to find the first repeated  and non-repeated characters in the given string 
//input: java is easy 
//output:first repeated character :a ,first non-repeated character j


package String;

public class Repeatandnonrepeat {
	
	public static void main(String[] args) {
		
		
		
	}

}
