package Com.Javatopics.Abstract;

public abstract class Iphone  implements mobilephone{
	public void callingfeature()
	{
	   System.out.println("The iphone mobile had calling feature");	
	}
	
	public void camerafeature()
	{
		System.out.println("The iphone mobile had camera feature");
	}
	
	public void speedcharging()
	{
		System.out.println("iphone had speed charging feature");
	}

	

}
