package constructor;

public class Super {
	
	
	int a;
	int b;
	int d;

	public Super(int a2, int b2, int c) {
		
		a  =a2;
	}
	
//    Super()
//   {
//	 System.out.println("No arugument constructor");  
//   }
//    Super(int a)
//    {
//    	System.out.println("one arugument constructor"+a);
//    }
//    Super(int a,int b)
//    {
//    	int c=a+b;
//    	System.out.println("two arugument constructor"+c);
//    }
   

}
