//DataType:what type of data we are storing inside the container(variable) we used to called as  data type
//Primitive Data type:byte(1),short(2),Int(4),Long(8),double(4),float(8),boolean,char(1 Bit)
//non primitive data types:Array,collection,class,Interface
package Com.Javatopics;

public class Datatypes {
	
	public static void main (String[]args)
	{
	     System.out.println(Byte.SIZE/8);
	     System.out.println(Byte.MAX_VALUE);
	     System.out.println(Byte.MIN_VALUE);
	     
	     
	     System.out.println(Short.SIZE/8);
	     System.out.println(Short.MAX_VALUE);
	     System.out.println(Short.MIN_VALUE);
	     
	     System.out.println(Integer.SIZE/8);
	     System.out.println(Integer.MAX_VALUE);
	     System.out.println(Integer.MIN_VALUE);
	     
	     System.out.println(Long.SIZE/8);
	     System.out.println(Long.MAX_VALUE);
	     System.out.println(Long.MIN_VALUE);
	     
	     System.out.println(Float.SIZE/8);
	     System.out.println(Float.MAX_VALUE);
	     System.out.println(Float.MIN_VALUE);
	     
	     System.out.println(Boolean.TRUE);
	     
	     System.out.println(Character.SIZE/8);
	     System.out.println(Character.MAX_VALUE);
	     System.out.println(Character.MIN_VALUE);

	     
	}

}
