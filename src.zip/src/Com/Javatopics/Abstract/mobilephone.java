package Com.Javatopics.Abstract;

public interface mobilephone {
	
	
	public void callingfeature();
	
	public void camerafeature();
	
	public void videocallfeature();
	
	public void gamesfeature();
	
	public void savepicturefeature();
	


}
