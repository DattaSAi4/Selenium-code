package Com.Javatopics.interfac;

public class Mphasis  implements Company1{

	
	public void idcard() {
		
		System.out.println("Mphasis should wear id card");
		
	}


	public void formaldress() {
	
		System.out.println("mphasis employess should wear formaldress");
		
	}

	
	public void nopendrives() {
		
		System.out.println("Mphasis employess should no bring pendrives to office ");
		
	}

	
	public static void shoes()
	{
		System.out.println("employee should wear formal shoes");
	}
}
