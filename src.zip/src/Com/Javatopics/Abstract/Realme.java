package Com.Javatopics.Abstract;

public class Realme extends oneplus {

	@Override
	public void videocallfeature() {
		System.out.println("The Realme  mobile had calling feature");
		
	}

	@Override
	public void gamesfeature() {
		System.out.println("The Realme mobile had gaming feature ");
		
	}

	@Override
	public void savepicturefeature() {
		System.out.println("The realme mobile had savepicturefeature");
		
	}

	@Override
	public void dustresidence() {
		System.out.println("The relame mobile had dustresidence");
		
	}

}
