package Selenium;

public enum Names {
	
	Vinay,Sai,Datta, 

}
