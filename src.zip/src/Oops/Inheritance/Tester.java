package Oops.Inheritance;

public class Tester {
	
	public void Readaccess()
	{
		System.out.println("he can See the code");
	}

}
