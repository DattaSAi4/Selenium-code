
/*//write a java program to count the number of character in a string 
//
//input :Java is  super output :13
*/

package String;

public class CountNumberOfcharacter {
	
	public static void main(String[] args) {
		
		       String name = "java is super";
		       
		      System.out.println(name.toCharArray().length);
	}

}
