package filehandling.Readthedata;

public class Bufferreader {
	
	

}
