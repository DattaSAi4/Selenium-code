package Array;

public class Counttheoccurancefromarray {

}
