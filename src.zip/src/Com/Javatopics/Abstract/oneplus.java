package Com.Javatopics.Abstract;

public abstract class oneplus implements mobilephone {
	
	public void callingfeature()
	{
	   System.out.println("The Oneplus mobile had calling feature");	
	}
	
	public void camerafeature()
	{
		System.out.println("The oneplus mobile had camera feature");
	}
	
	public void speedcharging()
	{
		System.out.println("Oneplus had speed charging feature");
	}
	
	public abstract void dustresidence();
	

}
