package interview;

public class class1 implements class0 {
	
	int a =10;
	int b =20;

	@Override
	public void addition() {
		
		int c= a+b;
		System.out.println("The Addition of two numbers"+c);
		
	}

	@Override
	public void substraction() {
		
		int d =a-b;
		System.out.println("The substraction of Two Number" +d);
		
	}

	@Override
	public void multiplication() {
		// TODO Auto-generated method stub
		
	}

}
