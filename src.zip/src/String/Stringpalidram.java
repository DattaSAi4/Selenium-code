//Write a java  program  to verify whether  teh given string is palidrom or not 
//input :javaj  output:It is a palidrom 
//input:Javaj    output: It is not a palidrom 


package String;

public class Stringpalidram {
	public static void main(String[] args) {
		
		String s1 ="JavaJ";
		String s2 ="Java";
		System.out.println(s2);
		System.out.println(s1==s2);
		System.out.println(s1.equals(s2));
		System.out.println(s1.compareTo(s2));
		
	}
	
	

}
