
/* 5.Find the minimum length word from an array and ping it along with its index
 * input:["coffee","milk","chai","Water" ,"coke"] output:value - chai & index-2*/

package Array;

public class Minimumlengthwords {
	
	public static void main(String[] args) {
		minlength();
	}

	public  static String minlength()
	{
		String[] coffeenames = {"coffee","milk","chai","Water" ,"coke"};
		
		String[] min =coffeenames[1].split(coffeenames[1], 5);
		
		System.out.println(min);
		
		for(int i =0; i>min.length;i++)
		{
	           
					}
		
		
		return null;
		
	}
}


