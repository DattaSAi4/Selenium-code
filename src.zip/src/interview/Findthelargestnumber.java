package interview;

public class Findthelargestnumber {
	public static void main(String[] args) {
		 int a =70;
		 int b =20;
		 int c= 300;
		 
		 if(a>b && a>c)
		 {
			 System.out.println(a);
		 }
		 else if(b>a && b>c)
		 {
			 System.out.println(b);
		 }
		 else
		 {
			 System.out.println(c);
		 }
		 
		 String s1 = "Datta123";
		    String s2 = s1.replace("[^0-9]", "");
		    System.out.println(s2);
	}
	
	
	
	        

}
