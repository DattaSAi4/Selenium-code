/*Interface:An interface is blueprint of the class

*/
package Com.Javatopics;

public class Interface {
	
	
	
	

}
