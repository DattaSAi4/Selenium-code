/*Write a java program  to the number of words in a Stirng
  input :java is programming lang   output: 4*/

package String;

import java.util.Arrays;

public class CountNumberofWord {
	
	
public static void main(String[] args) {
	 
	String name = "java is programming lang";
//	 System.out.println(Arrays.toString(name.split(" ")).length());
	      int  a =name.split(" ").length;
	      System.out.println(a);
}
	
	     

}
