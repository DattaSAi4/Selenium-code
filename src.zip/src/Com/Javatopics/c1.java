package Com.Javatopics;

public class c1 {
	
	int a =10;
	


}
