package Programs;

public class FindOutSecondHigheshNumber {
	
	public static void main(String[] args) {
		
		int[] arr = {1,23,4,567,6};
		
		int highesh =Integer.MIN_VALUE;
		
		System.out.println(highesh);
		
		int second = Integer.MIN_VALUE;
		
		System.out.println(second);
		
		for(int s1:arr)
		{
			  if(s1>highesh)
			  {
				        second =  highesh;
				       highesh= s1;
			  }
			  else if(s1>second)
			  {
				  second=s1;
			  }
			 
		}
		 System.out.println(second);
	}

}
