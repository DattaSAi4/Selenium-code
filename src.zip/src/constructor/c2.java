package constructor;

public class c2  extends c1{
	
	
	
	c2(int a) {
		super(a);
		
	}

	public void names()
	{
		System.out.println("vinay");
	}
	
public static void main(String[] args) {
	
	     c2 s1 = new c2(10);
}

}
