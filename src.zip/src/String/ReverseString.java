package String;

public class ReverseString {
	
	public static void main(String[] args) {
		
//		String s1 = "vinay";
//		String s2 ="sai";
//		
//	    String s4 = s1.toLowerCase();
//	    String s5 = s2.toLowerCase();
//	    
//	    for(int i=0;i<s4.length();i++)
//	    {
//	    	if(s4.charAt(i)==s5.charAt(i))
//	    	{
//	    		System.out.println("At this point the two string character matched");
//	    	}
//	    }
//	    
		
		System.out.println(" ,iyhknm,");
	}

}
