//single line comment
//multiple line comment 
//documentation comment used above the class and methods
package Com.Javatopics;

public class Comments {
	
//	ctrl+7 or crtl+/----->single line comment
//	ctrl+shift+/------>multi line comments
//	Shift+alt+j
//	for program aliment ctrl a + ctrli
	
	/*
	 * The given number is odd number Performs the Arithmatic operation****** Enter
	 * the A value
	 */
	

}
