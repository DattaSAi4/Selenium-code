package Oops.Inheritance;

public class Developer extends Tester {

	public void WriteAceess()
	{
		System.out.println("He can edit the code");
	}
	
	
}
